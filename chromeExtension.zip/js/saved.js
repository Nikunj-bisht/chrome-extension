


function geturl(){

    if(typeof(Storage)!=="undefined"){
    
    
    alert(localStorage.getItem("saved"));
    

    }else{
        alert("No item");

    }
    }
    geturl();
    
    
    
    
    
    
    
    
    